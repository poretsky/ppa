/* Russian TTS library */

#ifndef RU_TTS_H
#define RU_TTS_H

/* BEGIN_C_DECLS should be used at the beginning of C declarations,
   so that C++ compilers don't mangle their names.  Use END_C_DECLS at
   the end of C declarations. */
#undef BEGIN_C_DECLS
#undef END_C_DECLS
#ifdef __cplusplus
# define BEGIN_C_DECLS extern "C" {
# define END_C_DECLS }
#else
# define BEGIN_C_DECLS /* empty */
# define END_C_DECLS /* empty */
#endif

BEGIN_C_DECLS

typedef void (*ru_tts_callback)(void *buffer, unsigned int size);

/*
 * Perform TTS transformation for specified text.
 *
 * The first argument points to a zero-terminated string to transfer.
 * This string must contain a Russian text in koi8-r.
 * The next two arguments specify a buffer that will be used
 * by the library for delivering produced wave data
 * chunk by chunk to the consumer specified by the last argument.
 */
extern void ru_tts_transfer(char *text, void *wave_buffer, int wave_buffer_size,
                            ru_tts_callback wave_consumer);

/*
 * Setup speech parameters.
 *
 * The value of rate and pitch should be within [0..250] boundaries.
 * All other values will be reduced to this interval.
 * The last argument is treated as a logical value.
 * If it is zero the produced speech will be monotone.
 */
extern void ru_tts_setup(int rate, int pitch, int intonation);

/*
 * Load alternative voice data.
 *
 * The function specified as a callback should fill the provided buffer
 * with voice data. For instance, it can load it from a file.
 */
extern void ru_tts_set_voice_data(ru_tts_callback data_provider);

END_C_DECLS

#endif
