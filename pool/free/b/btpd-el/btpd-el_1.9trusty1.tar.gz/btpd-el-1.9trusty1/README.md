# btpd-el

This is an Emacs frontend for the
[Btpd BitTorrent client](https://github.com/btpd/btpd)
providing more or less intuitive and simple interface
to it's functions. It also communicates with
[Emacs-w3m web browser](https://www.emacswiki.org/emacs/emacs-w3m)
allowing to start torrent download just by clicking on a respective
 link. Torrent's content can be previewed as a virtual directory tree.

See [Debian package README](debian/README.Debian) for more details.
