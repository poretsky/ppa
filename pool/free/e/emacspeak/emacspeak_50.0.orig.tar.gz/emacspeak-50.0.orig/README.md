# Emacspeak: The Complete Audio Desktop
* [Download Release 49.0](https://github.com/tvraman/emacspeak/releases/download/49.0/emacspeak-49.0.tar.bz2)
* [Blog](http://tvraman.github.io/emacspeak/blog)  Articles  --- including  emacspeak.blogspot.com  posts.
* [Manual](http://tvraman.github.io/emacspeak/manual) Info manual for emacspeak.
* [Web](http://emacspeak.sf.net) Emacspeak Web Site.
*  [Videos](http://tvraman.github.io/emacspeak/videos) Video demos.
* [![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/tvraman/emacspeak?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
